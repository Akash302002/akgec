import React, { useState, useEffect } from "react";
import "./styles.css";
import axios from "axios";
import "./styles/tailwind-pre-build.css";

// Main App Component
const App = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    username: "",
  });
  const [employees, setEmployees] = useState([]);
  const [message, setMessage] = useState("");

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "https://jsonplaceholder.typicode.com/posts",
        formData
      );
      setMessage("User registered successfully! (Simulated)");
      console.log("POST Response:", response.data);
    } catch (error) {
      setMessage("Error registering user.");
      console.error("POST Error:", error);
    }
  };

  // Fetch employees on component mount
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await axios.get(
          "https://jsonplaceholder.typicode.com/users"
        );
        setEmployees(response.data);
      } catch (error) {
        console.error("GET Error:", error);
      }
    };
    fetchEmployees();
  }, []);

  return (
    <div className="min-h-screen bg-black-100 p-4">
      {/*  Form */}
      <div className="max-w-md mx-auto bg-black p-6 rounded shadow-md">
        <h2 className="text-xl font-bold mb-4">Register User</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label
              htmlFor="name"
              className="block text-sm font-medium text-gray-700"
            >
              Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>

          <div>
            <label
              htmlFor="email"
              className="block text-sm font-medium text-gray-700"
            >
              Email
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>

          <div>
            <label
              htmlFor="username"
              className="block text-sm font-medium text-gray-700"
            >
              Username
            </label>
            <input
              type="text"
              id="username"
              name="username"
              value={formData.username}
              onChange={handleInputChange}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-900 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            Submit
          </button>
        </form>

        {message && <p className="mt-4 text-green-500">{message}</p>}
      </div>

      {/* Employee List */}
      <div className="mt-8 max-w-4xl mx-auto bg-white p-6 rounded shadow-md">
        <h2 className="text-xl font-bold mb-4">Employee List</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {employees.map((employee) => (
            <div key={employee.id} className="p-4 border rounded shadow-sm">
              <h3 className="text-lg font-semibold">{employee.name}</h3>
              <p className="text-sm text-gray-600">Email: {employee.email}</p>
              <p className="text-sm text-gray-600">
                Username: {employee.username}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default App;
