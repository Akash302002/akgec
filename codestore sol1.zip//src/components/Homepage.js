import React from "react";

export default function HomePage() {
  return <h1>Welcome to Ticket Management System. </h1>;
}
