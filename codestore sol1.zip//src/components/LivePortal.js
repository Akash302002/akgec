import React from "react";

export default function LivePortal() {
  return <h1>Live Portal </h1>;
}
